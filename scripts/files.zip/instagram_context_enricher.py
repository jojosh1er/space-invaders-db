#!/usr/bin/env python3
"""
Instagram Context Enricher — Prototype Étape 2
================================================
Enrichit le géocodage d'un Invader en récupérant des photos contextuelles
postées par la communauté chasseur sur Instagram, puis en les passant à
Claude Vision en multi-image pour corroboration croisée.

Pipeline pour un Invader_id (ex. PA_1228):
  1. Charge credentials depuis ~/.invader_secrets/.env
  2. Login Instagram via instagrapi (session pickle pour éviter re-login)
  3. Throttling agressif (1 req/30s) pour limiter risque de ban
  4. Recherche hashtag #PA_1228
  5. Télécharge top 5 posts (photos + légende + géotag si présent)
  6. Cache disque: ~/.cache/invader_instagram/PA_1228/
  7. Appel Claude Vision multi-image avec prompt de corroboration:
       "Voici l'image officielle + N photos contextuelles. Identifie
        plaques de rue, enseignes, panneaux métro visibles. Corrobore
        entre images avant de proposer une adresse."
  8. Retourne dict enrichi avec:
       - adresse proposée (avec confiance recalibrée)
       - géotags instagram s'ils existent (signal direct)
       - nombre de sources corroborantes

Usage:
    # Test login (crée session.pkl la 1re fois)
    python instagram_context_enricher.py --login-test

    # Test sur un Invader
    python instagram_context_enricher.py --invader PA_1228 \
        --official-image path/to/invader_official.jpg

    # Vider cache d'un Invader pour re-scraper
    python instagram_context_enricher.py --clear PA_1228
"""

import os
import sys
import json
import time
import pickle
import shutil
import argparse
import base64
from pathlib import Path
from datetime import datetime

try:
    from dotenv import load_dotenv
    from instagrapi import Client
    from instagrapi.exceptions import LoginRequired, ChallengeRequired
except ImportError:
    print("⚠️  pip install python-dotenv instagrapi anthropic requis")
    raise

try:
    import anthropic
except ImportError:
    anthropic = None  # Vision step facultatif pour tests de scraping seul

# ─── Config ────────────────────────────────────────────────────────────────

SECRETS_PATH = Path.home() / ".invader_secrets" / ".env"
SESSION_PATH = Path.home() / ".invader_secrets" / "ig_session.pkl"
CACHE_ROOT = Path.home() / ".cache" / "invader_instagram"
CACHE_ROOT.mkdir(parents=True, exist_ok=True)

THROTTLE_SEC = 30           # 1 requête / 30s (conservateur)
MAX_POSTS_PER_INVADER = 5   # Limite téléchargements
LAST_REQUEST_TIME = [0.0]   # liste mutable = "variable globale throttle"

load_dotenv(SECRETS_PATH)


def throttle():
    """Garantit un délai minimum entre requêtes Instagram."""
    elapsed = time.time() - LAST_REQUEST_TIME[0]
    if elapsed < THROTTLE_SEC:
        wait = THROTTLE_SEC - elapsed
        print(f"  ⏳ throttle: attente {wait:.0f}s")
        time.sleep(wait)
    LAST_REQUEST_TIME[0] = time.time()


# ─── Session Instagram ─────────────────────────────────────────────────────

def get_client() -> Client:
    """
    Retourne un client instagrapi authentifié.
    Utilise session.pkl si existe (évite re-login → réduit risque ban).
    """
    username = os.getenv("IG_USERNAME")
    password = os.getenv("IG_PASSWORD")
    if not username or not password:
        raise RuntimeError(f"IG_USERNAME/IG_PASSWORD manquants dans {SECRETS_PATH}")

    cl = Client()
    cl.delay_range = [3, 7]  # délai interne entre appels API instagrapi

    if SESSION_PATH.exists():
        try:
            with open(SESSION_PATH, "rb") as f:
                cl.set_settings(pickle.load(f))
            cl.login(username, password)  # relogin silencieux si session valide
            cl.get_timeline_feed()  # ping de validation
            print("  🔐 Session Instagram réutilisée")
            return cl
        except (LoginRequired, Exception) as e:
            print(f"  ⚠️  Session invalide ({e}), re-login…")
            SESSION_PATH.unlink(missing_ok=True)

    # Login frais
    try:
        cl.login(username, password)
    except ChallengeRequired:
        print("  ❌ Challenge Instagram détecté. Résous-le manuellement")
        print("     dans l'app/web Instagram puis relance.")
        raise

    with open(SESSION_PATH, "wb") as f:
        pickle.dump(cl.get_settings(), f)
    os.chmod(SESSION_PATH, 0o600)
    print("  🔐 Nouvelle session Instagram créée")
    return cl


# ─── Scraping hashtag ──────────────────────────────────────────────────────

def fetch_invader_posts(cl: Client, invader_id: str, limit: int = MAX_POSTS_PER_INVADER):
    """
    Recherche #PA_1228 (format confirmé par l'utilisateur).
    Retourne liste de dicts: {media_id, caption, image_path, geotag, likes}
    """
    cache_dir = CACHE_ROOT / invader_id
    cache_meta = cache_dir / "posts.json"

    if cache_meta.exists():
        print(f"  💾 Cache hit: {invader_id}")
        with open(cache_meta) as f:
            return json.load(f)

    cache_dir.mkdir(parents=True, exist_ok=True)
    hashtag = invader_id  # sans le #, instagrapi ajoute

    throttle()
    print(f"  🔎 Recherche #{hashtag}…")
    try:
        medias = cl.hashtag_medias_recent(hashtag, amount=limit * 2)  # marge de filtre
    except Exception as e:
        print(f"  ❌ Recherche hashtag échouée: {e}")
        return []

    posts = []
    for m in medias[: limit * 2]:
        if len(posts) >= limit:
            break

        # Filtre: seulement images (pas reels/carrousels pour le proto)
        if m.media_type != 1:
            continue

        throttle()
        try:
            img_path = cl.photo_download(m.pk, folder=cache_dir)
        except Exception as e:
            print(f"  ⚠️  Download échec {m.pk}: {e}")
            continue

        geotag = None
        if m.location:
            geotag = {
                "name": m.location.name,
                "lat": m.location.lat,
                "lng": m.location.lng,
                "address": getattr(m.location, "address", None),
            }

        posts.append({
            "media_id": str(m.pk),
            "caption": (m.caption_text or "")[:500],
            "image_path": str(img_path),
            "geotag": geotag,
            "likes": m.like_count,
            "user": m.user.username,
            "taken_at": m.taken_at.isoformat() if m.taken_at else None,
        })

    with open(cache_meta, "w") as f:
        json.dump(posts, f, indent=2, ensure_ascii=False)
    print(f"  ✅ {len(posts)} posts téléchargés et cachés")
    return posts


# ─── Claude Vision multi-image ─────────────────────────────────────────────

VISION_PROMPT = """Tu es un expert en géolocalisation urbaine. Tu dois identifier \
l'emplacement précis d'une mosaïque Space Invader à Paris.

Tu reçois :
1. L'image officielle de la mosaïque (fournie par l'application FlashInvaders)
2. {n_context} photo(s) contextuelle(s) postée(s) par des chasseurs sur Instagram \
(hashtag #{invader_id})

MÉTHODE (strictement) :
- Examine CHAQUE photo contextuelle et liste tous les indices visibles :
  plaques de rue bleues (nom + numéro), enseignes commerciales, \
  panneaux de métro/bus, numéros de rue, architecture typique.
- CORROBORE entre plusieurs images : un indice n'est fiable que si au moins \
  2 images le confirment, OU s'il est clairement lisible sur une photo.
- Si les photos Insta ne montrent que la mosaïque en gros plan sans contexte, \
  dis-le explicitement et baisse la confiance.
- N'invente JAMAIS un nom de rue plausible : si tu ne lis pas de plaque, dis-le.

Légendes Instagram (à utiliser comme indice textuel, mais avec méfiance) :
{captions}

Géotags Instagram disponibles (si présents, signal fort) :
{geotags}

Réponds au format JSON strict :
{{
  "corroborated_indices": ["..."],
  "address": "...",
  "confidence": "HIGH|MEDIUM|LOW|NONE",
  "reasoning": "...",
  "used_geotag": true/false
}}"""


def img_to_b64(path: str) -> tuple[str, str]:
    """Retourne (media_type, base64) pour Claude API."""
    suffix = Path(path).suffix.lower()
    mt = {
        ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
        ".png": "image/png", ".webp": "image/webp",
    }.get(suffix, "image/jpeg")
    with open(path, "rb") as f:
        return mt, base64.standard_b64encode(f.read()).decode()


def analyze_with_vision(invader_id: str, official_image: str, posts: list):
    """Appel Claude multi-image avec corroboration croisée."""
    if anthropic is None:
        print("  ⚠️  anthropic package non installé — skip Vision")
        return None

    client = anthropic.Anthropic()  # lit ANTHROPIC_API_KEY depuis env

    content = []
    # Image 1 : officielle
    mt, b64 = img_to_b64(official_image)
    content.append({"type": "text", "text": "Image officielle :"})
    content.append({
        "type": "image",
        "source": {"type": "base64", "media_type": mt, "data": b64},
    })

    # Images contextuelles
    captions_block = []
    geotags_block = []
    for i, p in enumerate(posts, 1):
        mt, b64 = img_to_b64(p["image_path"])
        content.append({"type": "text", "text": f"Photo contextuelle {i} (par @{p['user']}):"})
        content.append({
            "type": "image",
            "source": {"type": "base64", "media_type": mt, "data": b64},
        })
        if p["caption"]:
            captions_block.append(f"[{i}] {p['caption']}")
        if p["geotag"]:
            g = p["geotag"]
            geotags_block.append(f"[{i}] {g['name']} ({g['lat']:.5f}, {g['lng']:.5f})")

    prompt = VISION_PROMPT.format(
        n_context=len(posts),
        invader_id=invader_id,
        captions="\n".join(captions_block) or "(aucune légende exploitable)",
        geotags="\n".join(geotags_block) or "(aucun géotag)",
    )
    content.append({"type": "text", "text": prompt})

    resp = client.messages.create(
        model="claude-sonnet-4-5",
        max_tokens=1024,
        messages=[{"role": "user", "content": content}],
    )
    text = resp.content[0].text
    # Extraction JSON
    try:
        start = text.find("{")
        end = text.rfind("}") + 1
        return json.loads(text[start:end])
    except Exception:
        return {"raw": text, "parse_error": True}


# ─── CLI ───────────────────────────────────────────────────────────────────

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--login-test", action="store_true", help="Teste login only")
    p.add_argument("--invader", help="ID Invader (ex: PA_1228)")
    p.add_argument("--official-image", help="Chemin image officielle FlashInvaders")
    p.add_argument("--clear", help="Vide le cache pour cet ID")
    p.add_argument("--no-vision", action="store_true", help="Skip appel Vision")
    args = p.parse_args()

    if args.clear:
        target = CACHE_ROOT / args.clear
        if target.exists():
            shutil.rmtree(target)
            print(f"✅ Cache vidé: {target}")
        return

    if args.login_test:
        cl = get_client()
        me = cl.account_info()
        print(f"✅ Connecté comme @{me.username}")
        return

    if not args.invader:
        p.print_help()
        return

    cl = get_client()
    posts = fetch_invader_posts(cl, args.invader)
    print(f"\n📦 {len(posts)} posts récupérés pour {args.invader}")
    for i, post in enumerate(posts, 1):
        geo = post.get("geotag")
        geo_str = f" @ {geo['name']}" if geo else ""
        print(f"  [{i}] @{post['user']} ({post['likes']} likes){geo_str}")
        print(f"      → {post['image_path']}")

    if args.no_vision or not args.official_image:
        print("\n⏭️  Skip Vision (pas d'image officielle ou --no-vision)")
        return

    if not posts:
        print("\n❌ Aucun post — pas d'enrichissement possible")
        return

    print("\n🧠 Analyse Claude Vision multi-image…")
    result = analyze_with_vision(args.invader, args.official_image, posts)
    print(json.dumps(result, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
